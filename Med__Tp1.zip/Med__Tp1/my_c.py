# This Python file uses the following encoding: utf-8
import sys
import librosa
import numpy as np
import matplotlib.pyplot as plt
from sklearn.mixture import GaussianMixture
from PySide6.QtWidgets import QApplication, QWidget, QPushButton, QFileDialog, QVBoxLayout, QHBoxLayout


class my_c(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Audio Processing Demo')

        # Create the main layout
        self.layout = QVBoxLayout(self)

        # Create the audio player figure
        self.fig_player = plt.figure(figsize=(8, 2))
        self.ax_player = self.fig_player.add_subplot(1, 1, 1)
        self.ax_player.set_title('Original Audio')

        # Create the audio processed figure
        self.fig_processed = plt.figure(figsize=(8, 2))
        self.ax_processed = self.fig_processed.add_subplot(1, 1, 1)
        self.ax_processed.set_title('Processed Audio')

        # Create the buttons layout
        self.layout_buttons = QHBoxLayout()

        # Create the Load WAV button
        self.btn_load_wav = QPushButton('Load WAV Audio')
        self.layout_buttons.addWidget(self.btn_load_wav)
        self.btn_load_wav.clicked.connect(self.load_wav)

        # Create the MFCC button
        self.btn_mfcc = QPushButton('MFCC Function')
        self.layout_buttons.addWidget(self.btn_mfcc)
        self.btn_mfcc.clicked.connect(self.run_mfcc)

        # Create the GMM button
        self.btn_gmm = QPushButton('GMM Function')
        self.layout_buttons.addWidget(self.btn_gmm)
        self.btn_gmm.clicked.connect(self.run_gmm)

        # Add the buttons layout to the main layout
        self.layout.addLayout(self.layout_buttons)

        # Add the audio player and processed figures to the main layout
        self.layout.addWidget(self.fig_player.canvas)
        self.layout.addWidget(self.fig_processed.canvas)

        # Initialize variables
        self.audio = None
        self.mfcc = None
        self.gmm = None

    def load_wav(self):
        # Open a file dialog to choose a WAV file
        file_dialog = QFileDialog(self)
        file_dialog.setNameFilter('WAV files (*.wav)')
        if file_dialog.exec_():
            filenames = file_dialog.selectedFiles()
            filename = filenames[0]
            # Load the audio file with librosa
            self.audio, sr = librosa.load(filename, sr=None)
            print('Loaded audio with shape:', self.audio.shape)
            # Update the audio player figure
            self.ax_player.clear()
            self.ax_player.plot(np.arange(self.audio.shape[0]) / sr, self.audio)
            self.ax_player.set_title('Original Audio')
            self.fig_player.canvas.draw()
        else:
            print('No audio loaded')




    def run_mfcc(self):
        if self.audio is not None:
            # Calculate the MFCC features with librosa
            self.mfcc = librosa.feature.mfcc(self.audio)
            print('Calculated MFCC with shape:', self.mfcc.shape)
            # Update the processed audio figure
            self.ax_processed.clear()
            librosa.display.specshow(self.mfcc, x_axis='time', ax=self.ax_processed)
            self.ax_processed.set_title('Processed Audio (MFCC)')
            self.fig_processed.canvas.draw()


        else:
            print('No audio loaded')
# ---------------------------------------------------------------#
def run_gmm(self):
     if self.mfcc is not None:
        # Fit a Gaussian mixture model to the MFCC features with scikit-learn
        n_components = 10
        self.gmm = GaussianMixture(n_components=n_components)
        self.gmm.fit(self.mfcc.T)
        print('Fit GMM with', n_components, 'components')

        # Create a new audio file with the GMM features
        hop_length = 512
        n_fft = 2048
        gmm_audio = np.zeros_like(self.audio)
        for i, start in enumerate(range(0, len(self.audio), hop_length)):
            end = start + n_fft
            mfcc_frame = self.mfcc[:, i]
            gmm_frame = self.gmm.predict(mfcc_frame.reshape(1, -1))
            gmm_coeffs = self.gmm.means_[gmm_frame].flatten()
            gmm_audio[start:end] = self.istft(gmm_coeffs)

        # Save the GMM audio file
        gmm_filename, _ = QFileDialog.getSaveFileName(self, 'Save GMM Audio', '', 'WAV files (*.wav)')
        if gmm_filename:
            librosa.output.write_wav(gmm_filename, gmm_audio, sr=self.sr)

        # Update the labels to display the results
        self.mfcc_label.setText('MFCC Result: ' + str(self.mfcc.shape))
        self.gmm_label.setText('GMM Result: ' + str(self.gmm.converged_))
     else:
        print('No MFCC features calculated')



if __name__ == "__main__":
    app = QApplication([])
    window = my_c()
    window.show()
    sys.exit(app.exec_())
